#! /bin/bash

#for file in `find test_problems/ -name "*.h"`; do echo $file; done

#for file in `find auxiliary/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find cond/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find dense_qp/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find ipm_core/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find ocp_qp/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find tree_ocp_qp/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find include/ -name "*.h"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find benchmark/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find benchmark/ -name "*.h"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find test_problems/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find test_problems/ -name "*.h"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find . -name "Makefile*"`; do cat utils/new_lic_makefile > temp && tail -n +35 $file >> temp && cat temp > $file; done

#for file in `find interfaces/matlab_octave/ -name "*.c"`; do cat utils/new_lic_c > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find interfaces/matlab_octave/ -name "*.m"`; do cat utils/new_lic_matlab > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find examples/matlab_octave/ -name "*.m"`; do cat utils/new_lic_matlab > temp && tail -n +35 $file >> temp && cat temp > $file; done

#for file in `find interfaces/python/ -name "*.py"`; do cat utils/new_lic_python > temp && tail -n +35 $file >> temp && cat temp > $file; done
#for file in `find examples/python/ -name "*.py"`; do cat utils/new_lic_python > temp && tail -n +35 $file >> temp && cat temp > $file; done
